
public class SetHours extends State {
	SimpleClock myclock;
	
	public SetHours(SimpleClock myclock) {
		super();
		this.myclock = myclock;
		//System.out.println("In SetHours");
	}

	@Override
	public void SetUIFeatures() {
		// TODO Auto-generated method stub
		//myclock.enableSetTimeUIFeatures();
	}

	@Override
	public void incrementHours() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void incrementMinutes() {
		// DO NOTHING
		
	}

	@Override
	public void incrementSeconds() {
		// DO NOTHING
		
	}

	@Override
	public void decrementHours() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void decrementMinutes() {
		// DO NOTHING
		
	}

	@Override
	public void decrementSeconds() {
		// DO NOTHING
		
	}

	@Override
	public void timeTicker() {
		// DO NOTHING
		
	}

	@Override
	public void changeMode() {
		myclock.setState(myclock.getSetMinutes());
		
	}

	@Override
	public void cancel() {
		myclock.setState(myclock.getDisplayTime());
		
	}
}