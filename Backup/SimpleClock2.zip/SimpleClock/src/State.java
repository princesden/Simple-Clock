
public abstract class State {
     
	public abstract void SetUIFeatures();
	
	public abstract void incrementHours();
	public abstract void incrementMinutes();
	public abstract void incrementSeconds();


	public abstract void decrementHours();
	public abstract void decrementMinutes();
	public abstract void decrementSeconds();

	public abstract void timeTicker();
	public abstract void changeMode();
	public abstract void cancel();
	
	

}