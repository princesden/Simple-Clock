
public class SetSeconds extends State {
	SimpleClock myclock;
	
	public SetSeconds(SimpleClock myclock) {
		super();
		this.myclock = myclock;
	}

	@Override
	public void SetUIFeatures() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void incrementHours() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void incrementMinutes() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void incrementSeconds() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void decrementHours() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void decrementMinutes() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void decrementSeconds() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void timeTicker() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void changeMode() {
		myclock.setState(myclock.getDisplayTime());
		
	}

	@Override
	public void cancel() {
		myclock.setState(myclock.getSetMinutes());
		
	}

}