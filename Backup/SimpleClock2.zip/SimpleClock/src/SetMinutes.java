public class SetMinutes extends State {
	SimpleClock myclock;
	
	public SetMinutes(SimpleClock myclock) {
		super();
		this.myclock = myclock;
	
	}

	@Override
	public void SetUIFeatures() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void incrementHours() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void incrementMinutes() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void incrementSeconds() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void decrementHours() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void decrementMinutes() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void decrementSeconds() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void timeTicker() {
		// DO NOTHING
		
	}

	@Override
	public void changeMode() {
		myclock.setState(myclock.getSetSeconds());
		
	}

	@Override
	public void cancel() {
		myclock.setState(myclock.getSetHours());
		
	}
}