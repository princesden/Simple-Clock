import javax.swing.Timer;



public class DisplayTime extends State {
	SimpleClock myclock;
	private Timer timer;
	
	public DisplayTime(SimpleClock myclock) {
		super();
		this.myclock = myclock;
	}

	@Override
	public void SetUIFeatures() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void incrementHours() {
		// DO NOTHING
		
	}

	@Override
	public void incrementMinutes() {
		// DO NOTHING
		
	}

	@Override
	public void incrementSeconds() {
		// DO NOTHING
		
	}

	@Override
	public void decrementHours() {
		// DO NOTHING
		
	}

	@Override
	public void decrementMinutes() {
		// DO NOTHING
		
	}

	@Override
	public void decrementSeconds() {
		// DO NOTHING
		
	}

	@Override
	public void timeTicker() {
		//TimeTicker should be working and implemented here.~	
		//timer = new Timer(1000, myclock.timerAction);
		//timer.start();
		
	}

	@Override
	public void changeMode() {
		myclock.setState(myclock.getSetHours());
		
	}

	@Override
	public void cancel() {
		// DO NOTHING
		
	}
}