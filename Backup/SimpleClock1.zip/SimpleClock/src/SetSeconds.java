
public class SetSeconds extends State {

	@Override
	public void increment() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void decrement() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void changeMode() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void timeTicker() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void cancel() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void SetUIFeatures() {
		// TODO Auto-generated method stub
		
	}

   

}