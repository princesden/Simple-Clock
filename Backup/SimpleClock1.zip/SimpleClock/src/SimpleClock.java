import java.awt.EventQueue;


import javax.swing.BorderFactory;
//import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.Timer;

import java.awt.Panel;
import java.awt.Color;
import java.awt.Font;

public class SimpleClock {

	private JFrame frame;
	private Timer timer;

	State DisplayTime;
	State SetHours;
	State SetMinutes;
	State SetSeconds;
	
	State state = DisplayTime;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SimpleClock window = new SimpleClock();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SimpleClock() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		// Change Mode Button
		JButton btnChangeMode = new JButton("Change Mode");
		btnChangeMode.setBounds(148, 223, 139, 29);
		frame.getContentPane().add(btnChangeMode);

		// Hour Panel
		Panel hourPanel = new Panel();
		hourPanel.setBackground(Color.BLACK);
		hourPanel.setBounds(31, 57, 84, 74);
		frame.getContentPane().add(hourPanel);

		JLabel lblHour = new JLabel("12");
		lblHour.setFont(new Font("Courier", Font.PLAIN, 63));
		lblHour.setForeground(Color.WHITE);
		lblHour.setBorder(BorderFactory.createLineBorder(Color.white)); //Border
		hourPanel.add(lblHour);

		// Minute Panel
		Panel minutePanel = new Panel();
		minutePanel.setBackground(Color.BLACK);
		minutePanel.setBounds(179, 57, 84, 74);
		frame.getContentPane().add(minutePanel);

		JLabel lblMinute = new JLabel("3");
		lblMinute.setForeground(Color.WHITE);
		lblMinute.setFont(new Font("Courier", Font.PLAIN, 63));
		minutePanel.add(lblMinute);

		// Seconds Panel
		Panel secondsPanel = new Panel();
		secondsPanel.setBackground(Color.BLACK);
		secondsPanel.setBounds(326, 57, 84, 74);
		frame.getContentPane().add(secondsPanel);

		JLabel lblSeconds = new JLabel("55");
		lblSeconds.setForeground(Color.WHITE);
		lblSeconds.setFont(new Font("Courier", Font.PLAIN, 63));
		secondsPanel.add(lblSeconds);

		// The dots that appear in between Digits 12 : 5 : 22
		JLabel labeldot = new JLabel(":");
		labeldot.setFont(new Font("Courier Prime", Font.PLAIN, 57));
		labeldot.setBounds(124, 39, 49, 109);
		frame.getContentPane().add(labeldot);

		JLabel labeldot1 = new JLabel(":");
		labeldot1.setFont(new Font("Courier Prime", Font.PLAIN, 57));
		labeldot1.setBounds(271, 39, 49, 109);
		frame.getContentPane().add(labeldot1);
	}

	/**** Methods for Changing UI ****/
	public void enableSetTimeUIFeatures() {
		// Cancel Button
		JButton btnCancel = new JButton("Cancel");
		btnCancel.setBounds(310, 223, 117, 29);
		frame.getContentPane().add(btnCancel);// This is active now but should
												// not be until change mode is
												// clicked.

		// Increment Button
		JButton plusButton = new JButton("+");
		plusButton.setBounds(19, 223, 49, 29);
		frame.getContentPane().add(plusButton); // This is active now but should
												// not be until change mode is
												// clicked.

		// Decrement Button
		JButton minusButton = new JButton("-");
		minusButton.setBounds(66, 223, 49, 29);
		frame.getContentPane().add(minusButton);// This is active now but should
												// not be until change mode is
												// clicked.

	}
     public void changeState(State aState){
    	 
     }
	/**** Methods for Incrementing Time ****/
	public void incrementHours() {
		// TODO implement here
	}

	public void incrementMinutes() {
		// TODO implement here
	}

	public void incrementSeconds() {
		// TODO implement here
	}

	public void decrementHours() {
		// TODO implement here
	}

	public void decrementMinutes() {
		// TODO implement here
	}

	public void decrementSeconds() {
		// TODO implement here
	}

}
