
public class DisplayTime extends State {
    SimpleClock myclock;
    
    public DisplayTime(SimpleClock myclock){
    	this.myclock = myclock;
    }
	
	@Override
	public void increment() {
		// TODO Auto-generated method stub
		//Call SimpleClock.IncrementHours to Increase hours
	}

	@Override
	public void decrement() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void changeMode() {
		// TODO Auto-generated method stub
		//SimpleClock.lblHour.setBorder(BorderFactory.createLineBorder(Color.white));
	//myclock.changeState() = new see
	}

	@Override
	public void timeTicker() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void cancel() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void SetUIFeatures() {
		// TODO Auto-generated method stub
		
	}

    
}