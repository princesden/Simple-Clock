
public abstract class State {
     
	public State() {
		
	}
	
	public abstract void SetUIFeatures();
	
	public void setState(){
		
	}
	public abstract void increment();

	public abstract void decrement();

	public abstract void changeMode();

	public abstract void timeTicker();

	public abstract void cancel();
	
	

}