
public class SetSeconds extends State {
	SimpleClock myclock;
	
	public SetSeconds(SimpleClock myclock) {
		super();
		this.myclock = myclock;
	}

	@Override
	public void SetUIFeatures() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void increment() {
		System.out.println("In SetSeconds Increament");
		
	}

	@Override
	public void decrement() {
		System.out.println("In SetSeconds Decreament");
		
	}

	@Override
	public void timeTicker() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void changeMode() {
		myclock.setState(myclock.getDisplayTime());
		
	}

	@Override
	public void cancel() {
		myclock.setState(myclock.getSetMinutes());
		
	}

}