import javax.swing.Timer;



public class DisplayTime extends State {
	SimpleClock myclock;
	private Timer timer;
	
	public DisplayTime(SimpleClock myclock) {
		super();
		this.myclock = myclock;
		myclock.timeTicker();
	}

	@Override
	public void SetUIFeatures() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void increment() {
		// DO NOTHING
		
	}

	@Override
	public void decrement() {
		// DO NOTHING
		
	}

	@Override
	public void timeTicker() {
		
		
	}

	@Override
	public void changeMode() {
		myclock.setState(myclock.getSetHours());
		
	}

	@Override
	public void cancel() {
		// DO NOTHING
		
	}
}