
public class SetHours extends State {
	SimpleClock myclock;
	
	public SetHours(SimpleClock myclock) {
		super();
		this.myclock = myclock;
		//System.out.println("In SetHours");
	}

	@Override
	public void SetUIFeatures() {
		// TODO Auto-generated method stub
		//myclock.enableSetTimeUIFeatures();
	}

	@Override
	public void increment() {
		// TODO Auto-generated method stub
		System.out.println("In SetHours Increament");
		
	}

	@Override
	public void decrement() {
		System.out.println("In SetHours Decreament");
		
	}

	@Override
	public void timeTicker() {
		// DO NOTHING
		
	}

	@Override
	public void changeMode() {
		myclock.setState(myclock.getSetMinutes());
		
	}

	@Override
	public void cancel() {
		myclock.setState(myclock.getDisplayTime());
		
	}
}